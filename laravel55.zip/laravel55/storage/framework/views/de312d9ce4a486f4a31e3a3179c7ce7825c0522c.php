<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form>
		<table>
			<tr>
				<td>姓名</td>
				<td><input type="text" name="name"></td>
			</tr>
			<tr>
				<td>密码</td>
				<td><input type="password" name="pwd"></td>
			</tr>
			<tr>
				<td><input type="submit" value="提交" name=""></td>
			</tr>
		</table>
	</form>
</body>
</html>